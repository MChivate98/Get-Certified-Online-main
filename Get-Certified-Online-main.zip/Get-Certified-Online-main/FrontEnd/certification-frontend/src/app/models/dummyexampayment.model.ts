
export class DummyPayment {
    paymentMode: string
    paymentDate: Date
    amount: number
    userId: number
    expMonth: string
    expYear: number
    cardNumber: string
    cvv: number
    name: string
   
}