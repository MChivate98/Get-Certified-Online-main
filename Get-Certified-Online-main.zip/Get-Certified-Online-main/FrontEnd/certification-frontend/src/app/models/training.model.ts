export class Training{
    trainingProgramId :string;
    trainingCourse: string;
    description : string;
    trainingCost : number;
    noOfDays : number;
    
}