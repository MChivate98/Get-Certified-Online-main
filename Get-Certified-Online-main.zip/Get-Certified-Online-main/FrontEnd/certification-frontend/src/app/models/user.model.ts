export class User {
  userId: string;
  firstName: string;
  lastName: string;
  userName: string;
  password: string;
  mobileNo: string;
  email: string;
  gender: string;
  role: string;
  dateOfBirth: Date;
  address : string;
city: string;
district :string;
state : string;
otp : number;
securityQuestion : string;
securityAnswer : string;


}