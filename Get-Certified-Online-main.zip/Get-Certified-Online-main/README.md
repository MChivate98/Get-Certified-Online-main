# Get-Certification-online

Get Certified Online is a FullStack Web Application for Online training and Certification Exam for few technical courses. It is developed using with Microservices and RESTapis as Backend and Database as Mysql. It's Frontend is designed using Angular 8.

*List of Microservices
1)Login Microservice
2)User Microservice
3)Exam Microservice
4)Trainiing Microservice
5)Payment Microservice
